


    connection.commit()

    return order_id

'order_details': [
              {
                  'product_id': 1,
                  'quantity': 2,
                  'total_price': 50
              },
              {
                  'product_id': 3,
                  'quantity': 1,
                  'total_price': 30
              }
          ]